#include<stdio.h>
int add(int a, int b){
return a+b;
}
void print(int a){
	while(a>0){
		printf("%d", a%10);
		a/=10;
	}
}

int main(int argc, char **argv){
	int t =add(12,13);
	print(t);
}
