#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<inttypes.h>
int add(int, int);
ssize_t write(int fd, const void *buf, size_t count);
void _exit(int status);
int main(){
	int t = add(12,13);
	int  x = t;
	int num = 4;
	char *c = malloc(num*sizeof(char));
	num--;
	while(t>0){
		c[num] = (char)(48+(t%10));
		t/=10;
		num--;
	}
	printf("%d", x);
	_exit;
}
