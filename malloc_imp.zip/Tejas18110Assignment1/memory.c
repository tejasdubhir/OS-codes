#define _GNU_SOURCE

#include <stdio.h>
#include<math.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#include <assert.h>
#include "memory.h"

#define PAGE_SIZE 4096

struct page_metadata {
	int allocation_size;
	long long free_bytes_available;
};

long long int page_data[9];

struct node
{
	struct node* next;
	struct node* prev;
	char* address ; 
};

struct node* free_array[9];
// memset(free_array, NULL, 9*sizeof(int));

static void *alloc_from_ram(size_t size)
{
	assert((size % PAGE_SIZE) == 0 && "size must be multiples of 4096");
	void* base = mmap(NULL, size, PROT_READ|PROT_WRITE, MAP_ANON|MAP_PRIVATE, -1, 0);
	if (base == MAP_FAILED)
	{
		printf("Unable to allocate RAM space\n");
		exit(0);
	}
	return base;
}

static void free_ram(void *addr, size_t size)
{
	munmap(addr, size);
}

void add(int i, struct node* ptr){
	struct node* addit = free_array[i];
	while(addit->next != NULL){
		addit = addit->next;
	}
	addit->next = ptr;
	ptr->next = NULL;
	page_data[i]+= pow(2, i+4);
}

void myfree(void *ptr)
{
	for(int i =0 ; i<9 ; i++){
		if(page_data[i]> PAGE_SIZE- 16){
			free_ram((void*)free_array[i], PAGE_SIZE);
		}
	}
	for(int i =0 ; i<9 ; i++){
		struct node* ptr_forloop = (struct node*) ptr;
		int size ;
		if(page_data[i] == 0 ){
			continue;
		}
		else{
			while(ptr_forloop->prev != NULL){
				ptr_forloop = ptr_forloop->prev;
			}
			if(free_array[i] == ptr_forloop){
				add(i, ptr);
				if(page_data[i]== PAGE_SIZE-16){
					free_ram((void*)free_array[i], PAGE_SIZE);
				}
			}
			else{
				continue;
			}
		}
	}
	return;
	printf("myfree is not implemented\n");
	abort();
}

struct node* create_space(int rounded_size, int i){
	void* alloc_ptr = alloc_from_ram(PAGE_SIZE);
	struct node* head ;
	free_array[i] = head;
	struct page_metadata pm;
	pm.allocation_size = PAGE_SIZE;
	pm.free_bytes_available = PAGE_SIZE - 16;
	struct node* ptr = (struct node*) alloc_ptr;
	struct node* ptr_for_free = head;
	int ii = 0;
	while(pm.free_bytes_available> 0){
		ptr_for_free ->next = ptr;
		ptr_for_free = ptr_for_free->next;
		ptr -= rounded_size;
		ii++;
		pm.free_bytes_available -= rounded_size;
	}
	ptr_for_free->prev-> next = NULL;
	page_data[i] = pm.free_bytes_available;
	return ptr_for_free;
}

void *mymalloc(size_t size)
{
	if(size<= 0 ){
	return NULL;
	}

	if(size>  PAGE_SIZE - 16){
		struct node* ans = NULL;
		struct node* pts = ans;
		while(size>0){
			pts ->next = alloc_from_ram( PAGE_SIZE);
			pts= pts->next;
			size-= PAGE_SIZE;
		}
		return ans;
	}

	int rounded_size = size;
	int i;

	for(i =0 ; i<9; i++){
		if(size> (int)pow(2, (i+4)))
		continue;
		else{
			rounded_size = (int)pow(2, i+4);
		}
	}

	if(free_array[i]!= NULL){
		struct node* ptr = free_array[i];
		while(ptr != NULL){
			ptr = ptr->next;
		}
		(ptr->prev)->next = NULL;
		return ptr;
	}

	struct node* bucket = create_space(rounded_size, i);
	return bucket;

	printf("mymalloc is not implemented\n");	
	abort();
	return NULL;
}
